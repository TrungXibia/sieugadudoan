// /netlify/functions/getLottery.js
import fetch from 'node-fetch';

export async function handler(event, context) {
  const dai = event.queryStringParameters?.dai || 'bidu';
  const limit = event.queryStringParameters?.limit || 100;
  const url = `https://www.kqxs88.live/api/front/open/lottery/history/list/game?limitNum=${limit}&gameCode=${dai}`;

  try {
    const res = await fetch(url);
    if (!res.ok) return { statusCode: res.status, body: 'Error fetching API' };
    const json = await res.json();
    return { statusCode: 200, body: JSON.stringify(json) };
  } catch (e) {
    return { statusCode: 500, body: e.message };
  }
}
